"""Deserializacija podatkov iz XML datotek."""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
import argparse
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


MAPA = Path(__file__).resolve().parent
DATA_MAPA = MAPA / "data"


@dataclass
class Paket:
    id: str
    naziv: str
    destinacija: str
    trajanje_dni: int
    cena: Decimal
    datum_zacetka: date
    datum_zadnje_nabave: date | None
    opis: str


@dataclass
class Narocnik:
    id: str
    ime: str
    priimek: str
    email: str
    kraj: str
    datum_registracije: date
    stevilo_oseb: int


@dataclass
class Narocilo:
    id: str
    narocnik_id: str
    paket_id: str
    datum_narocila: date
    stevilo_oseb: int
    znesek: Decimal
    status: str


@dataclass
class PovezanoNarocilo:
    narocilo: Narocilo
    narocnik: Narocnik
    paket: Paket


def besedilo(element: ET.Element, ime: str) -> str:
    """Obvezno besedilo elementa."""
    otrok = element.find(ime)
    if otrok is None or otrok.text is None or not otrok.text.strip():
        raise ValueError(f"V elementu <{element.tag}> manjka vrednost <{ime}>.")
    return otrok.text.strip()


def besedilo_ali_prazno(element: ET.Element, ime: str) -> str:
    """Element ne obstaja ali nima vrednosti -> prazno besedilo."""
    otrok = element.find(ime)
    if otrok is None or otrok.text is None:
        return ""
    return otrok.text.strip()


def atribut_id(element: ET.Element) -> str:
    """Branje atributa ID."""
    vrednost = element.get("id")
    if not vrednost:
        raise ValueError(f"Element <{element.tag}> nima atributa id.")
    return vrednost


def preberi_pakete(pot: Path) -> list[Paket]:
    """Deserializacija paketov."""
    koren = ET.parse(pot).getroot()
    return [
        Paket(
            id=atribut_id(e),
            naziv=besedilo(e, "naziv"),
            destinacija=besedilo(e, "destinacija"),
            trajanje_dni=int(besedilo(e, "trajanjeDni")),
            cena=Decimal(besedilo(e, "cena")),
            datum_zacetka=date.fromisoformat(besedilo(e, "datumZacetka")),
            datum_zadnje_nabave=(
                date.fromisoformat(v)
                if (v := besedilo_ali_prazno(e, "datumZadnjeNabave"))
                else None
            ),
            opis=besedilo(e, "opis"),
        )
        for e in koren.findall("paket")
    ]


def preberi_narocnike(pot: Path) -> list[Narocnik]:
    """Deserializacija naročnikov."""
    koren = ET.parse(pot).getroot()
    return [
        Narocnik(
            id=atribut_id(e),
            ime=besedilo(e, "ime"),
            priimek=besedilo(e, "priimek"),
            email=besedilo(e, "email"),
            kraj=besedilo(e, "kraj"),
            datum_registracije=date.fromisoformat(besedilo(e, "datumRegistracije")),
            stevilo_oseb=int(besedilo(e, "steviloOseb")),
        )
        for e in koren.findall("narocnik")
    ]


def preberi_narocila(pot: Path) -> list[Narocilo]:
    """Deserializacija naročil."""
    koren = ET.parse(pot).getroot()
    return [
        Narocilo(
            id=atribut_id(e),
            narocnik_id=besedilo(e, "narocnikId"),
            paket_id=besedilo(e, "paketId"),
            datum_narocila=date.fromisoformat(besedilo(e, "datumNarocila")),
            stevilo_oseb=int(besedilo(e, "steviloOseb")),
            znesek=Decimal(besedilo(e, "znesek")),
            status=besedilo(e, "status"),
        )
        for e in koren.findall("narocilo")
    ]


def povezi_podatke(
    narocila: list[Narocilo], narocniki: list[Narocnik], paketi: list[Paket]
) -> list[PovezanoNarocilo]:
    """Povezovanje narocil z naroniki in paketi prek IDjev."""
    narocniki_po_id = {narocnik.id: narocnik for narocnik in narocniki}
    paketi_po_id = {paket.id: paket for paket in paketi}
    povezano = []

    for narocilo in narocila:
        if narocilo.narocnik_id not in narocniki_po_id:
            raise ValueError(f"Naročnik z ID {narocilo.narocnik_id} ne obstaja.")
        if narocilo.paket_id not in paketi_po_id:
            raise ValueError(f"Paket z ID {narocilo.paket_id} ne obstaja.")
        povezano.append(
            PovezanoNarocilo(
                narocilo=narocilo,
                narocnik=narocniki_po_id[narocilo.narocnik_id],
                paket=paketi_po_id[narocilo.paket_id],
            )
        )
    return povezano


def filtriraj(
    narocila: list[PovezanoNarocilo],
    od_datuma: date | None,
    destinacija: str | None,
    status: str | None,
) -> list[PovezanoNarocilo]:
    """Filtriranje po datumu, destinaciji in statusu."""
    rezultat = narocila
    if od_datuma:
        rezultat = [x for x in rezultat if x.narocilo.datum_narocila >= od_datuma]
    if destinacija:
        rezultat = [
            x for x in rezultat if destinacija.casefold() in x.paket.destinacija.casefold()
        ]
    if status:
        rezultat = [x for x in rezultat if status.casefold() in x.narocilo.status.casefold()]
    return rezultat


def izpisi_tabelo(narocila: list[PovezanoNarocilo]) -> None:
    """Izpis povezanih naročil v konzolo."""
    glava = ("ID", "Datum", "Naročnik", "Paket", "Destinacija", "Znesek", "Status")
    vrstice = [
        (
            x.narocilo.id,
            x.narocilo.datum_narocila.isoformat(),
            f"{x.narocnik.ime} {x.narocnik.priimek}",
            x.paket.naziv,
            x.paket.destinacija,
            f"{x.narocilo.znesek:.2f} EUR",
            x.narocilo.status,
        )
        for x in narocila
    ]
    sirine = [max([len(glava[i]), *(len(r[i]) for r in vrstice)]) for i in range(len(glava))]
    print(" | ".join(glava[i].ljust(sirine[i]) for i in range(len(glava))))
    print("-+-".join("-" * sirina for sirina in sirine))
    for vrstica in vrstice:
        print(" | ".join(vrstica[i].ljust(sirine[i]) for i in range(len(glava))))
    print(f"Skupaj: {len(vrstice)} naročil")


def izvozi_json(narocila: list[PovezanoNarocilo], pot: Path) -> None:
    """Izvoz filtriranih naročil v JSON."""
    podatki = [
        {
            "id": x.narocilo.id,
            "datumNarocila": x.narocilo.datum_narocila.isoformat(),
            "status": x.narocilo.status,
            "steviloOseb": x.narocilo.stevilo_oseb,
            "znesek": float(x.narocilo.znesek),
            "narocnik": {
                "id": x.narocnik.id,
                "ime": x.narocnik.ime,
                "priimek": x.narocnik.priimek,
                "email": x.narocnik.email,
            },
            "paket": {
                "id": x.paket.id,
                "naziv": x.paket.naziv,
                "destinacija": x.paket.destinacija,
                "cena": float(x.paket.cena),
            },
        }
        for x in narocila
    ]
    pot.write_text(json.dumps(podatki, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def izvozi_xml(narocila: list[PovezanoNarocilo], pot: Path) -> None:
    """Izvoz filtriranih naročil v XML."""
    koren = ET.Element("narocila")
    for x in narocila:
        narocilo = ET.SubElement(koren, "narocilo", {"id": x.narocilo.id})
        ET.SubElement(narocilo, "datumNarocila").text = x.narocilo.datum_narocila.isoformat()
        ET.SubElement(narocilo, "status").text = x.narocilo.status
        ET.SubElement(narocilo, "steviloOseb").text = str(x.narocilo.stevilo_oseb)
        ET.SubElement(narocilo, "znesek").text = str(x.narocilo.znesek)

        narocnik = ET.SubElement(narocilo, "narocnik", {"id": x.narocnik.id})
        ET.SubElement(narocnik, "ime").text = x.narocnik.ime
        ET.SubElement(narocnik, "priimek").text = x.narocnik.priimek
        ET.SubElement(narocnik, "email").text = x.narocnik.email

        paket = ET.SubElement(narocilo, "paket", {"id": x.paket.id})
        ET.SubElement(paket, "naziv").text = x.paket.naziv
        ET.SubElement(paket, "destinacija").text = x.paket.destinacija
        ET.SubElement(paket, "cena").text = str(x.paket.cena)

    drevo = ET.ElementTree(koren)
    ET.indent(drevo, space="  ")
    drevo.write(pot, encoding="utf-8", xml_declaration=True)


def main() -> None:
    """Nalaganje, povezovanje in filtriranje XML podatkov."""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Pregled povezanih potovalnih naročil.")
    parser.add_argument("--od-datuma", help="Prikaži naročila od datuma YYYY-MM-DD naprej")
    parser.add_argument("--destinacija", help="Filtriraj po delu imena destinacije")
    parser.add_argument("--status", help="Filtriraj po delu statusa naročila")
    args = parser.parse_args()

    try:
        od_datuma = date.fromisoformat(args.od_datuma) if args.od_datuma else None
    except ValueError as napaka:
        parser.error(f"Neveljaven datum: {napaka}. Uporabi obliko YYYY-MM-DD.")

    paketi = preberi_pakete(DATA_MAPA / "paketi.xml")
    narocniki = preberi_narocnike(DATA_MAPA / "narocniki.xml")
    narocila = preberi_narocila(DATA_MAPA / "narocila.xml")
    povezana = povezi_podatke(narocila, narocniki, paketi)
    rezultat = filtriraj(povezana, od_datuma, args.destinacija, args.status)
    izpisi_tabelo(rezultat)
    izvozi_json(rezultat, MAPA / "filtrirano.json")
    izvozi_xml(rezultat, MAPA / "filtrirano.xml")
    print("Izvoz shranjen v filtrirano.json in filtrirano.xml")


if __name__ == "__main__":
    main()
