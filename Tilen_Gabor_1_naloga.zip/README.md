# Potovalna agencija – XML in JSON

## Opis

Projekt prikazuje branje XML dokumentov, deserializacijo v Python objekte, povezovanje naročil z naročniki in paketi prek ID-jev, filtriranje ter izvoz rezultatov v JSON in XML.

Vhodne datoteke so v mapi `data/`:

- `paketi.xml` – 11 potovalnih paketov
- `narocniki.xml` – 11 naročnikov
- `narocila.xml` – 11 naročil s sklici na ID-je naročnikov in paketov

## Zagon

Potrebujete Python 3.10 ali novejši. V terminalu se postavite v mapo projekta in zaženite:

```bash
python aplikacija.py
```

Program izpiše povezana naročila v konzolo ter ustvari oziroma prepiše `filtrirano.json` in `filtrirano.xml`.

## Primeri filtrov

```bash
python aplikacija.py --od-datuma 2026-03-08
python aplikacija.py --destinacija Bled
python aplikacija.py --status potrjeno
python aplikacija.py --od-datuma 2026-03-08 --status potrjeno
```

Filtri se lahko kombinirajo. Datum je v obliki `YYYY-MM-DD`; destinacija in status se iščeta po delu besedila.

## Izhodne datoteke

- `filtrirano.json` – seznam filtriranih naročil z vključenimi podatki o naročniku in paketu
- `filtrirano.xml` – isti filtrirani podatki v XML obliki

Ob zagonu brez filtrov izhodni datoteki vsebujeta vseh 11 naročil.
